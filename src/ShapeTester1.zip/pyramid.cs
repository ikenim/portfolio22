using System;

namespace PyramidApp
{
    class Pyramid
    {
        // member variables
        private double length;
        private double breadth;
        private double height;
        
        public void setLength(double len)
        {
            length = len;
        }
        public void setBreadth(double bre)
        {
            breadth = bre;
        }
        public void setHeight(double hei)
        {
            height = hei;
        }
        public double getVolume()
        {
            return length * breadth * height / 3;
        }
        public double getSurface()
        {
            return length * breadth + length * Math.Sqrt(Math.Pow(breadth/2,2)+Math.Pow(height,2))+breadth * Math.Sqrt(Math.Pow(length/2,2)+Math.Pow(height,2));
        }
    }
    //tester
    class Pyramidbuilder
    {
        static void Main(string[] args)
        {
            Pyramid Pyramid1 = new Pyramid();
            double vol;
            double sa;
            Pyramid1.setLength(Convert.ToInt32(Console.ReadLine()));
            Pyramid1.setBreadth(Convert.ToInt32(Console.ReadLine()));
            Pyramid1.setHeight(Convert.ToInt32(Console.ReadLine()));
          
            vol = Pyramid1.getVolume();
            sa = Pyramid1.getSurface();
            Console.WriteLine("Volume of Pyramid1: {0}", vol);
            Console.WriteLine("Total Surface Area of Pyramid1: {0}", sa);
        }
    }
}