using System;

namespace SphereApp
{
    class Sphere
    {
        // member variables
        private double radius;
        private double pi = 3.14;
        
        public void setRadius(double rad)
        {
            radius = rad;
        }
        public double getVolume()
        {
            return radius * pi * 4 / 3;
        }
        public double getSurface()
        {
            return 4 * pi * Math.Pow(radius,2);
        }
    }
    //tester
    class Spherebuilder
    {
        static void Main(string[] args)
        {
            Sphere Sphere1 = new Sphere();
            double vol;
            double sa;
            Sphere1.setRadius(Convert.ToInt32(Console.ReadLine()));

            vol = Sphere1.getVolume();
            sa = Sphere1.getSurface();
            Console.WriteLine("Volume of Sphere1: {0}", vol);
            Console.WriteLine("Surface Area of Sphere1: {0}", sa);
        }
    }
}