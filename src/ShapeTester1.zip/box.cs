using System;

namespace BoxApp
{
    class Box
    {
        // member variables
        private double length;
        private double breadth;
        private double height;

        public void setLength(double len)
        {
            length = len;
        }
        public void setBreadth(double bre)
        {
            breadth = bre;
        }
        public void setHeight(double hei)
        {
            height = hei;
        }
        public double getVolume()
        {
            return length * breadth * height;
        }
        public double getSurface()
        {
            return 2 * length * height + 2 * length * breadth + 2 * breadth * height;
        }
    }
    //tester
    class Boxbuilder
    {
        static void Main(string[] args)
        {
            Box Box1 = new Box();
            double vol;
            double sa;
            Box1.setLength(Convert.ToInt32(Console.ReadLine()));
            Box1.setBreadth(Convert.ToInt32(Console.ReadLine()));
            Box1.setHeight(Convert.ToInt32(Console.ReadLine()));

            vol = Box1.getVolume();
            sa = Box1.getSurface();
            Console.WriteLine("Volume of Box1: {0}", vol);
            Console.WriteLine("Surface Area of Box1: {0}", sa);
        }
    }
}