using System;
using BoxApp;
using SphereApp;
using PyramidApp;

class Program
{
    public static void Main(string[] args)
    {
      String response;
      double vol;
      double sa;
      double val;
        Console.WriteLine("Welcome to the shape maker.\nLets find the volume and surface area for a few shapes.");
        Console.WriteLine("To build a box, press 1.\nTo build a sphere, press 2.\nTo build a square pyramid, press 3.");
        response = Console.ReadLine();
        if (response == "1")
        {
          Box Box1 = new Box();
          Console.WriteLine("Welcome to the box tester.");
          Console.WriteLine("Please enter the length:");
          val = Convert.ToInt32(Console.ReadLine());
          Box1.setLength(val);
          Console.WriteLine("Please enter the height:");
          val = Convert.ToInt32(Console.ReadLine());
          Box1.setHeight(val);
          Console.WriteLine("Please enter the breadth:");
          val = Convert.ToInt32(Console.ReadLine());
          Box1.setBreadth(val);

          vol = Box1.getVolume();
          sa = Box1.getSurface();
          Console.WriteLine("Volume of Box1: {0}", vol);
          Console.WriteLine("Surface Area of Box1: {0}", sa);
        }
        else if (response == "2")
        {
          Sphere Sphere1 = new Sphere();
          Console.WriteLine("Welcome to the sphere tester.");
          Console.WriteLine("Please enter the radius:");
          val = Convert.ToInt32(Console.ReadLine());
          Sphere1.setRadius(val);
          
          vol = Sphere1.getVolume();
          sa = Sphere1.getSurface();
          Console.WriteLine("Volume of Sphere1: {0}", vol);
          Console.WriteLine("Surface Area of Sphere1: {0}", sa);
        }
        else if (response == "3")
        {
           Pyramid Pyramid1 = new Pyramid();
          Console.WriteLine("Welcome to the pyramid tester.");
          Console.WriteLine("Please enter the length:");
          val = Convert.ToInt32(Console.ReadLine());
          Pyramid1.setLength(val);
          Console.WriteLine("Please enter the breadth:");
          val = Convert.ToInt32(Console.ReadLine());
          Pyramid1.setBreadth(val);
          Console.WriteLine("Please enter the height:");
          val = Convert.ToInt32(Console.ReadLine());
          Pyramid1.setHeight(val);
                      
          vol = Pyramid1.getVolume();
          sa = Pyramid1.getSurface();
          Console.WriteLine("Volume of Pyramid1: {0}", vol);
          Console.WriteLine("Total Surface Area of Pyramid1: {0}", sa);
        } Console.WriteLine("\nConnection terminated.");
    }
}